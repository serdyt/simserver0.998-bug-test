#define GPIO_D_BASE 0x40020C00
#define GPIO_D_MODER ((volatile unsigned long *) GPIO_D_BASE + 0x0)
#define GPIO_D_OTYPER ((volatile unsigned short *) (GPIO_D_BASE + 0x4))
#define GPIO_D_OSPEEDR ((volatile unsigned long *) (GPIO_D_BASE + 0x8))
#define GPIO_D_PUPDR ((volatile unsigned long *) (GPIO_D_BASE + 0xC))
#define GPIO_D_IDR ((volatile unsigned short *) (GPIO_D_BASE + 0x10))
#define GPIO_D_ODR ((volatile unsigned short *) (GPIO_D_BASE + 0x14))