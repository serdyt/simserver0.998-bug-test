#include "gpio.h"
#include <stdbool.h>

const unsigned char key_value[4][4] = {
    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'}
};

const unsigned char seven_segment_codes[16] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F, // 9
    0x77, // A
    0x7C, // B
    0x39, // C
    0x5E, // D
};

void init_GPIO(){
    *GPIO_D_MODER = 0x55005555;
    *GPIO_D_PUPDR = 0x00AA0000; 
    *GPIO_D_OTYPER = 0x0000;
    *GPIO_D_OSPEEDR = 0x55555555;
}

void activate_row(int row){
    *GPIO_D_ODR &= 0x0FFF;
    *GPIO_D_ODR |= 0b1<<(8+4+row);
}

//Returns the column number at which a key is pressed in the interval [0, 3]
//If no key is pressed, returns 0xFF
unsigned char read_column(){
    unsigned volatile short kepad_output = *GPIO_D_IDR;
    
    if (!kepad_output){
        return 0xFF;
    }

    kepad_output &= 0x0F00;
    kepad_output = kepad_output >> 8;

    char column = 0;
    while (kepad_output){
        kepad_output = kepad_output >> 1;
        column++;
    }

    return column-1;
}

char read_keyboard(){
    unsigned char key = 0xFF;
    for (int row = 0; row < 4; row++){
        activate_row(row);
        unsigned char column = read_column();
        if (column != 0xFF){
            key = key_value[row][column];
            return key;
        }
    }
}

int ascii_to_int(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    } else if (c >= 'a' && c <= 'f') {
        return c - 'a' + 10;
    } else if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    } else if (c == '*') {
        return 0x42;
    } else if (c == '#') {
        return 0x35;
    } else {
        return -1;
    }
}

void output_7_segment(char c){
    int index = ascii_to_int(c);
    if (index < 0 || index > 13){
        *GPIO_D_ODR = 0b10000000;
    } else{
        *GPIO_D_ODR = seven_segment_codes[index];
    }
}

void main(void){
    init_GPIO();

    while(true){
        unsigned char c = read_keyboard();
        output_7_segment(c);
        }
}